# Vliv parametru Temperature na podobnost a kvalitu kódu generovaného velkými jazykovými modely

Bakalářská práce, Aplikovaná informatika, Přírodovědecká fakulta UJEP

**Autor:** Filip Stehlík
**Vedoucí práce:** Ing. Mgr. Pavel Beránek

## O práci

Tato bakalářská práce zkoumá vliv teplotního parametru (temperature) na kvalitu a podobnost kódu generovaného třemi současnými velkými jazykovými modely (GPT-4.1, Claude Sonnet 4, Gemini 2.5 Pro).

### Hlavní zjištění

1. **Teplota NEMÁ vliv na kvalitu kódu**
   - Všechny metriky kvality (funkční správnost, cyklomatická složitost, Halsteadovy metriky, Maintainability Index) zůstávají konstantní napříč teplotami T ∈ [0.0, 1.0]
   - Korelace: |r| < 0.04, p > 0.2 pro všechny metriky
   - Funkční správnost: 68-70% bez ohledu na teplotu

2. **Teplota MÁ silný vliv na podobnost kódu**
   - BLEU klesá o 35%: z 0.481 (T=0.0) na 0.313 (T=1.0), r = -0.350
   - CodeBLEU klesá o 21%: z 0.570 na 0.449, r = -0.315
   - AST Edit Distance a TSED rostou o 31%, r ≈ 0.12
   - Vyšší teplota = větší diverzita bez ztráty kvality

3. **Rozdíly mezi modely**
   - Claude Sonnet 4: Nejcitlivější na změnu teploty (R² = 0.346 pro BLEU)
   - Gemini 2.5 Pro: Nejstabilnější (R² = 0.062 pro BLEU)
   - ChatGPT 4.1: Střední citlivost (R² = 0.089 pro BLEU)

### Experiment

- **Rozsah:** 1,080 vygenerovaných Python souborů
- **Design:** 3 modely × 3 úlohy × 6 teplot × 20 iterací
- **Teploty:** 0.0, 0.2, 0.4, 0.6, 0.8, 1.0
- **Úlohy:** calculator, ascii_art, todo_list
- **Metriky kvality:** Kompilovatelnost, pass rate, cyklomatická složitost, Halstead (Volume/Difficulty/Effort), Maintainability Index
- **Metriky podobnosti:** BLEU, CodeBLEU, AST Edit Distance, TSED

## Struktura projektu

```
thesis_ki_ujep/
├── ki-thesis.tex           # Hlavní soubor práce
├── ki-thesis.pdf           # Vygenerovaná PDF
├── thesis.bib              # Bibliografická databáze (BibLaTeX)
├── kitheses.cls            # Třída dokumentu pro UJEP
├── history_nlp.jpg         # Ilustrace vývoje NLP
├── CLAUDE.md               # Dokumentace pro Claude Code
├── NAVRH_2.3_IMPLEMENTACE.md  # Design dokumentace kapitoly 2.3
└── README.md               # Tento soubor
```

## Kompilace

### Pomocí latexmk (doporučeno)

```bash
latexmk -pdf ki-thesis.tex
```

### Manuální kompilace

```bash
pdflatex ki-thesis.tex
biber ki-thesis
pdflatex ki-thesis.tex
pdflatex ki-thesis.tex
```

### Vyčištění dočasných souborů

```bash
latexmk -c ki-thesis.tex
```

### Vyčištění všech generovaných souborů (včetně PDF)

```bash
latexmk -C ki-thesis.tex
```

## Požadované balíčky LaTeX

- **Třída dokumentu:** kitheses.cls (součástí repozitáře)
- **Fonty:** Libertinus Serif/Sans/Math, Source Code Pro
- **Babel:** czech
- **Bibliografie:** biblatex, biber (styl: iso-numeric)
- **Grafika:** graphicx, tikz
- **Kód:** listings (Python syntax)
- **Matematika:** amsmath, amssymb

## Kapitoly

### Teoretická část

1. **Velké jazykové modely** - Architektura Transformer, autoregresivní modely, attention mechanism
2. **Nástroje pro generování kódu** - GitHub Copilot, Cursor, Claude Code, temperature parameter
3. **Abstraktní syntaktické stromy** - AST vs CST, Python ast modul
4. **Metriky statické kvality kódu** - Halsteadovy metriky, cyklomatická složitost, Maintainability Index
5. **Hodnocení programové podobnosti** - BLEU, CodeBLEU, AST Edit Distance, TSED
6. **Přehled současného stavu poznání** - Studie o vlivu temperature na LLM výstupy

### Praktická část

1. **Metodika výzkumu** - Design experimentu, výzkumné otázky
2. **Explorační analýza** - Přehled předchozích studií
3. **Implementace nástrojů** - Python skripty pro vyhodnocení metrik (3 subsekce s kódem)
4. **Provedení experimentu** - Výsledky experimentu s vizualizacemi
5. **Závěr** - Odpovědi na výzkumné otázky, omezení, budoucí práce

## Externí přílohy

Experimentální data a zdrojové kódy jsou umístěny v samostatném repozitáři:

**GitHub:** https://github.com/stehlfi1/serial_experiment_temperature

Repozitář obsahuje:
- Vygenerované Python soubory (1,080 souborů)
- Skripty pro analýzu (`experiment_runner.py`, `enhanced_plots.py`, atd.)
- Výsledky měření metrik (CSV soubory)
- Vizualizace (PDF grafy)

## Technologie

- **LaTeX distribuce:** TeX Live 2024 nebo novější
- **Compiler:** LuaLaTeX nebo PDFLaTeX
- **Bibliografie:** Biber 2.19+
- **Editace:** VS Code s LaTeX Workshop extension (doporučeno)

## Verifikace výsledků

Všechny statistické hodnoty v práci byly ověřeny pomocí Python skriptů:
- `/tmp/final_check.py` - Kompletní verifikace všech čísel
- `/tmp/verify_stats.py` - Kontrola korelací a regresí
- `/tmp/verify_ranges.py` - Kontrola rozsahů a průměrů
- `/tmp/consistency_check.txt` - Zpráva o logické konzistenci kapitol 2.4 a 3

**Výsledek verifikace:** ✓✓✓ ALL VERIFICATIONS PASSED ✓✓✓

## Citace

```bibtex
@thesis{stehlik2026temperature,
  author    = {Filip Stehlík},
  title     = {Vliv parametru Temperature na podobnost a kvalitu kódu
               generovaného velkými jazykovými modely},
  type      = {Bakalářská práce},
  school    = {Univerzita Jana Evangelisty Purkyně v Ústí nad Labem},
  year      = {2026},
  note      = {Vedoucí práce: Ing. Mgr. Pavel Beránek}
}
```

## Licence

Tato práce je šířena pod licencí Creative Commons BY-NC-SA 4.0 (uvedení autora, nekomerční využití, zachování licence).

## Kontakt

**Filip Stehlík**
Přírodovědecká fakulta UJEP
Ústí nad Labem, Česká republika

---

**Datum obhajoby:** 2026
**Status:** Dokončeno - Finální verze
